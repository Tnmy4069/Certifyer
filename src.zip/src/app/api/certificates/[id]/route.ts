import { NextRequest } from "next/server";
import { requireAdmin } from "@/auth";
import { AppError, jsonError, jsonOk, parseJson } from "@/lib/api";
import { connectDb } from "@/lib/db";
import { enqueueCertificateGeneration, processGenerationQueue } from "@/lib/generation/queue";
import { AuditEvent, Certificate, Event } from "@/models";
import mongoose from "mongoose";

type Params = { params: Promise<{ id: string }> };

async function getAdminCertificate(id: string, userId: string) {
  if (!mongoose.isValidObjectId(id)) throw new AppError("Certificate not found", 404);
  const certificate = await Certificate.findById(id);
  if (!certificate) throw new AppError("Certificate not found", 404);
  const event = await Event.findOne({ _id: certificate.eventId, createdBy: userId });
  if (!event) throw new AppError("Certificate not found", 404);
  return { certificate, event };
}

export async function POST(request: NextRequest, { params }: Params) {
  try {
    const session = await requireAdmin();
    const { id } = await params;
    await connectDb();
    const { certificate, event } = await getAdminCertificate(id, session.user.id);
    const body = await parseJson<{ action: "regenerate" | "revoke" | "restore" }>(request);

    if (body.action === "revoke") {
      certificate.status = "REVOKED";
      certificate.revokedAt = new Date();
      await certificate.save();
      await AuditEvent.create({
        eventId: event._id,
        certificateId: certificate._id,
        actorType: "ADMIN",
        actorId: session.user.id,
        action: "certificate.revoked",
      });
      return jsonOk({ certificate: { id: String(certificate._id), status: certificate.status } });
    }

    if (body.action === "restore") {
      if (certificate.status !== "REVOKED") throw new AppError("Only revoked certificates can be restored", 400);
      certificate.status = certificate.pngKey ? "GENERATED" : "PENDING";
      certificate.revokedAt = null;
      await certificate.save();
      await AuditEvent.create({
        eventId: event._id,
        certificateId: certificate._id,
        actorType: "ADMIN",
        actorId: session.user.id,
        action: "certificate.restored",
      });
      return jsonOk({ certificate: { id: String(certificate._id), status: certificate.status } });
    }

    if (body.action === "regenerate") {
      const batch = await enqueueCertificateGeneration({
        eventId: event._id,
        userId: session.user.id,
        certificateIds: [String(certificate._id)],
      });
      await processGenerationQueue({ limit: 1, workerId: `api-${session.user.id}` });
      return jsonOk({ batchId: String(batch._id), message: "Regeneration queued" });
    }

    throw new AppError("Unknown action", 400);
  } catch (error) {
    return jsonError(error);
  }
}
