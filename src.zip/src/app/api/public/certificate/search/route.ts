import { NextRequest } from "next/server";
import { z } from "zod";
import { AppError, jsonError, jsonOk, parseJson } from "@/lib/api";
import { connectDb } from "@/lib/db";
import { getCandidateAccessProvider } from "@/lib/candidate-access";
import { getClientIp, rateLimit } from "@/lib/security/rate-limit";
import { getStorage } from "@/lib/storage";
import { AuditEvent, Candidate, Certificate, Event } from "@/models";

const searchSchema = z.object({
  eventSlug: z.string().min(1),
  email: z.string().email(),
});

export async function POST(request: NextRequest) {
  try {
    const ip = getClientIp(request);
    const limited = rateLimit(`public-search:${ip}`, 10, 60_000);
    if (!limited.ok) throw new AppError("Too many requests. Please try again shortly.", 429, "RATE_LIMITED");

    const body = searchSchema.parse(await parseJson(request));
    await connectDb();

    const event = await Event.findOne({ slug: body.eventSlug, status: "PUBLISHED" });
    // Generic response to reduce enumeration
    if (!event) {
      throw new AppError("No certificate found for this email.", 404, "NOT_FOUND");
    }

    const emailLimited = rateLimit(`public-search-email:${body.email.toLowerCase()}`, 8, 60_000);
    if (!emailLimited.ok) throw new AppError("Too many requests. Please try again shortly.", 429, "RATE_LIMITED");

    const candidate = await Candidate.findOne({ eventId: event._id, email: body.email.toLowerCase() });
    if (!candidate) {
      throw new AppError("No certificate found for this email.", 404, "NOT_FOUND");
    }

    const certificate = await Certificate.findOne({
      eventId: event._id,
      candidateId: candidate._id,
      status: { $in: ["GENERATED", "REVOKED"] },
    });

    if (!certificate || certificate.status !== "GENERATED" || !certificate.pngKey) {
      throw new AppError("No certificate found for this email.", 404, "NOT_FOUND");
    }

    const access = await getCandidateAccessProvider().requestAccess({
      eventId: String(event._id),
      email: candidate.email,
    });

    const storage = getStorage();

    await AuditEvent.create({
      eventId: event._id,
      certificateId: certificate._id,
      actorType: "CANDIDATE",
      actorId: candidate.email,
      action: "certificate.lookup",
    });

    return jsonOk({
      accessToken: access.token,
      certificate: {
        certificateNumber: certificate.certificateNumber,
        candidateName: candidate.name,
        eventName: event.name,
        issuedAt: certificate.issuedAt,
        pngUrl: storage.createSignedUrl(certificate.pngKey, 15 * 60),
        pdfUrl: certificate.pdfKey ? storage.createSignedUrl(certificate.pdfKey, 15 * 60) : null,
      },
    });
  } catch (error) {
    return jsonError(error);
  }
}
