"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { EventNav } from "@/components/admin/event-nav";

type CertificateRow = {
  id: string;
  certificateNumber: string;
  status: string;
  issuedAt?: string;
  downloadCount: number;
  failureReason?: string | null;
  candidate: { id: string; name: string; email: string } | null;
  pngUrl?: string | null;
  pdfUrl?: string | null;
};

export function CertificatesManager({ eventId }: { eventId: string }) {
  const [certificates, setCertificates] = useState<CertificateRow[]>([]);
  const [q, setQ] = useState("");
  const [status, setStatus] = useState("");
  const [loading, setLoading] = useState(true);
  const [batchId, setBatchId] = useState<string | null>(null);
  const [progress, setProgress] = useState<{
    percent: number;
    completed: number;
    failed: number;
    total: number;
    status: string;
  } | null>(null);

  const load = useCallback(async () => {
    const params = new URLSearchParams();
    if (q) params.set("q", q);
    if (status) params.set("status", status);
    const response = await fetch(`/api/events/${eventId}/certificates?${params.toString()}`);
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Failed to load certificates");
    setCertificates(data.certificates);
  }, [eventId, q, status]);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        await load();
      } catch (error) {
        if (!cancelled) toast.error(error instanceof Error ? error.message : "Failed to load");
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [load]);

  useEffect(() => {
    if (!batchId) return;
    const timer = setInterval(async () => {
      try {
        await fetch("/api/worker/tick", { method: "POST" }).catch(() => undefined);
        const response = await fetch(`/api/events/${eventId}/certificates?batchId=${batchId}`);
        const data = await response.json();
        if (data.progress) {
          setProgress(data.progress);
          if (data.progress.status === "COMPLETED" || data.progress.status === "FAILED") {
            clearInterval(timer);
            setBatchId(null);
            await load();
            toast.success("Generation finished");
          }
        }
      } catch {
        // ignore transient polling errors
      }
    }, 1500);
    return () => clearInterval(timer);
  }, [batchId, eventId, load]);

  const failedCount = useMemo(() => certificates.filter((c) => c.status === "FAILED").length, [certificates]);

  async function generate(onlyFailed = false) {
    try {
      const response = await fetch(`/api/events/${eventId}/certificates`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ onlyFailed, processInline: true }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Failed to start generation");
      setBatchId(data.batch.id);
      setProgress({ percent: 0, completed: 0, failed: 0, total: data.batch.total, status: "QUEUED" });
      toast.success("Generating certificates...");
      await load();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Generation failed");
    }
  }

  async function act(id: string, action: "regenerate" | "revoke" | "restore") {
    try {
      const response = await fetch(`/api/certificates/${id}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Action failed");
      toast.success(`Certificate ${action}d`);
      await load();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Action failed");
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Certificates</h1>
          <p className="mt-1 text-sm text-muted-foreground">Generate, review, revoke, and download certificates.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          {failedCount > 0 ? (
            <Button variant="outline" onClick={() => generate(true)}>
              Retry failed ({failedCount})
            </Button>
          ) : null}
          <Button onClick={() => generate(false)}>Generate Certificates</Button>
        </div>
      </div>

      <EventNav eventId={eventId} />

      {progress ? (
        <Card>
          <CardHeader>
            <CardTitle>Generating certificates...</CardTitle>
            <CardDescription>
              {progress.completed} / {progress.total} completed
              {progress.failed ? ` · ${progress.failed} failed` : ""}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Progress value={progress.percent} />
            <p className="mt-2 text-sm text-muted-foreground">{progress.percent}%</p>
          </CardContent>
        </Card>
      ) : null}

      <Card>
        <CardHeader>
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <CardTitle>Certificate list</CardTitle>
              <CardDescription>Search and manage issued certificates.</CardDescription>
            </div>
            <div className="flex gap-2">
              <Input placeholder="Search candidate or ID" value={q} onChange={(e) => setQ(e.target.value)} className="w-56" />
              <select
                className="h-10 rounded-lg border border-border bg-card px-3 text-sm"
                value={status}
                onChange={(e) => setStatus(e.target.value)}
              >
                <option value="">All statuses</option>
                <option value="PENDING">Pending</option>
                <option value="GENERATED">Generated</option>
                <option value="FAILED">Failed</option>
                <option value="REVOKED">Revoked</option>
              </select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <p className="text-sm text-muted-foreground">Loading...</p>
          ) : certificates.length === 0 ? (
            <p className="text-sm text-muted-foreground">No certificates yet. Import candidates, then generate.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[900px] text-left text-sm">
                <thead className="border-b text-muted-foreground">
                  <tr>
                    <th className="pb-3 font-medium">Certificate ID</th>
                    <th className="pb-3 font-medium">Candidate</th>
                    <th className="pb-3 font-medium">Email</th>
                    <th className="pb-3 font-medium">Status</th>
                    <th className="pb-3 font-medium">Downloads</th>
                    <th className="pb-3 font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {certificates.map((cert) => (
                    <tr key={cert.id} className="border-b last:border-0">
                      <td className="py-3 font-medium">{cert.certificateNumber}</td>
                      <td className="py-3">{cert.candidate?.name || "—"}</td>
                      <td className="py-3 text-muted-foreground">{cert.candidate?.email || "—"}</td>
                      <td className="py-3">
                        <Badge
                          variant={
                            cert.status === "GENERATED"
                              ? "success"
                              : cert.status === "FAILED"
                                ? "destructive"
                                : cert.status === "REVOKED"
                                  ? "warning"
                                  : "outline"
                          }
                        >
                          {cert.status}
                        </Badge>
                        {cert.failureReason ? <p className="mt-1 text-xs text-red-600">{cert.failureReason}</p> : null}
                      </td>
                      <td className="py-3">{cert.downloadCount}</td>
                      <td className="py-3">
                        <div className="flex flex-wrap gap-2">
                          {cert.pngUrl ? (
                            <Button asChild size="sm" variant="outline">
                              <a href={cert.pngUrl} target="_blank" rel="noreferrer">
                                PNG
                              </a>
                            </Button>
                          ) : null}
                          {cert.pdfUrl ? (
                            <Button asChild size="sm" variant="outline">
                              <a href={cert.pdfUrl} target="_blank" rel="noreferrer">
                                PDF
                              </a>
                            </Button>
                          ) : null}
                          <Button size="sm" variant="secondary" onClick={() => act(cert.id, "regenerate")}>
                            Regenerate
                          </Button>
                          {cert.status === "REVOKED" ? (
                            <Button size="sm" variant="outline" onClick={() => act(cert.id, "restore")}>
                              Restore
                            </Button>
                          ) : (
                            <Button size="sm" variant="destructive" onClick={() => act(cert.id, "revoke")}>
                              Revoke
                            </Button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
