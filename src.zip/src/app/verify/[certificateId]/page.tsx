import { connectDb } from "@/lib/db";
import { formatDate } from "@/lib/utils";
import { AuditEvent, Candidate, Certificate, Event } from "@/models";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

type Params = { params: Promise<{ certificateId: string }> };

export default async function VerifyPage({ params }: Params) {
  const { certificateId } = await params;
  await connectDb();

  const certificate = await Certificate.findOne({
    certificateNumber: certificateId.toUpperCase(),
  });

  if (!certificate || (certificate.status !== "GENERATED" && certificate.status !== "REVOKED")) {
    return (
      <div className="mx-auto flex min-h-screen max-w-lg items-center px-4">
        <Card className="w-full">
          <CardHeader>
            <CardTitle>Certificate not found</CardTitle>
            <CardDescription>We could not verify this certificate ID.</CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  const [event, candidate] = await Promise.all([
    Event.findById(certificate.eventId),
    Candidate.findById(certificate.candidateId),
  ]);

  certificate.verificationCount += 1;
  await certificate.save();
  if (event) {
    await Event.findByIdAndUpdate(event._id, { $inc: { verificationCount: 1 } });
  }
  await AuditEvent.create({
    eventId: certificate.eventId,
    certificateId: certificate._id,
    actorType: "PUBLIC",
    action: "certificate.verified.page",
  });

  const revoked = certificate.status === "REVOKED";

  return (
    <div className="mx-auto flex min-h-screen max-w-lg items-center px-4 py-10">
      <Card className="w-full">
        <CardHeader>
          <div className="flex items-center justify-between gap-3">
            <CardTitle>{revoked ? "Certificate Revoked" : "Certificate Verified"}</CardTitle>
            <Badge variant={revoked ? "warning" : "success"}>{revoked ? "REVOKED" : "VERIFIED"}</Badge>
          </div>
          <CardDescription>
            {revoked ? "This certificate has been revoked by the organizer." : "This certificate is authentic."}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3 text-sm">
          <Row label="Candidate" value={candidate?.name || "—"} />
          <Row label="Event" value={event?.name || "—"} />
          <Row label="Certificate ID" value={certificate.certificateNumber} />
          <Row label="Issued" value={formatDate(certificate.issuedAt)} />
          <Row label="Organizer" value={event?.organizerName || "—"} />
          {revoked ? <Row label="Revoked" value={formatDate(certificate.revokedAt)} /> : null}
        </CardContent>
      </Card>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-start justify-between gap-4 border-b border-border/70 py-2 last:border-0">
      <span className="text-muted-foreground">{label}</span>
      <span className="text-right font-medium">{value}</span>
    </div>
  );
}
