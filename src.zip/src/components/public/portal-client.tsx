"use client";

import { FormEvent, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

type FoundCertificate = {
  certificateNumber: string;
  candidateName: string;
  eventName: string;
  issuedAt?: string;
  pngUrl: string;
  pdfUrl?: string | null;
};

export function PublicPortalClient({
  eventSlug,
  eventName,
}: {
  eventSlug: string;
  eventName: string;
}) {
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [certificate, setCertificate] = useState<FoundCertificate | null>(null);

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setLoading(true);
    setCertificate(null);
    try {
      const response = await fetch("/api/public/certificate/search", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ eventSlug, email }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "No certificate found for this email.");
      setAccessToken(data.accessToken);
      setCertificate(data.certificate);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Lookup failed");
    } finally {
      setLoading(false);
    }
  }

  function downloadUrl(format: "png" | "pdf") {
    if (!certificate || !accessToken) return "#";
    const params = new URLSearchParams({
      eventSlug,
      email,
      token: accessToken,
      format,
    });
    return `/api/public/certificate/${certificate.certificateNumber}/download?${params.toString()}`;
  }

  return (
    <div className="mx-auto flex min-h-screen w-full max-w-lg flex-col justify-center px-4 py-10">
      <div className="mb-8 text-center">
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground">Certify</p>
        <h1 className="mt-3 text-3xl font-semibold tracking-tight">Download your certificate</h1>
        <p className="mt-2 text-sm text-muted-foreground">{eventName}</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Find certificate</CardTitle>
          <CardDescription>Enter the email address used during registration.</CardDescription>
        </CardHeader>
        <CardContent>
          <form className="space-y-4" onSubmit={onSubmit}>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
              />
            </div>
            <Button className="w-full" type="submit" disabled={loading}>
              {loading ? "Searching..." : "Find Certificate"}
            </Button>
          </form>
        </CardContent>
      </Card>

      {certificate ? (
        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Certificate Found</CardTitle>
            <CardDescription>Your certificate is ready to download.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-1 text-sm">
              <p>
                <span className="text-muted-foreground">Candidate:</span> {certificate.candidateName}
              </p>
              <p>
                <span className="text-muted-foreground">Event:</span> {certificate.eventName}
              </p>
              <p>
                <span className="text-muted-foreground">Certificate ID:</span> {certificate.certificateNumber}
              </p>
            </div>
            <div className="overflow-hidden rounded-lg border bg-muted/30">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={certificate.pngUrl} alt="Certificate preview" className="h-auto w-full" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Button asChild variant="outline">
                <a href={downloadUrl("png")}>Download PNG</a>
              </Button>
              <Button asChild>
                <a href={downloadUrl("pdf")}>Download PDF</a>
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : null}
    </div>
  );
}
